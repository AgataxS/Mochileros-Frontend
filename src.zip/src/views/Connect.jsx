import React from 'react';

const Connect = () => {
  return (
    <div>
      <h1>Explora y conecta</h1>
    </div>
  );
};

export default Connect;
