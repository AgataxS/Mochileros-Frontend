import React from 'react';

const Forum = () => {
  return (
    <div>
      <h1>Crea un foro</h1>
    </div>
  );
};

export default Forum;
